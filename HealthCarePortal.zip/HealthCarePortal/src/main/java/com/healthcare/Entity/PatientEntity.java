package com.healthcare.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PatientEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Id;
	private String PatientName;
	private String Age;
	private String Patienthistroy;
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getPatienthistroy() {
		return Patienthistroy;
	}
	public void setPatienthistroy(String patienthistroy) {
		Patienthistroy = patienthistroy;
	}
	@Override
	public String toString() {
		return "PatientEntity [Id=" + Id + ", PatientName=" + PatientName + ", Age=" + Age + ", Patienthistroy="
				+ Patienthistroy + "]";
	}

}
