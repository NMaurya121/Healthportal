package com.healthcare.service;

import com.healthcare.pojo.Patient;

public interface PatientService {

	public void saveAllRecords(Patient patient);

	public void EditRecordsforPatient(Patient patient);
	
	void deleteRecordsforPatient(Long id);

}
