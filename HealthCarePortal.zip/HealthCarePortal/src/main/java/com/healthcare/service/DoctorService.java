package com.healthcare.service;

import com.healthcare.pojo.Doctor;

public interface DoctorService {
	
	 public void saveAllRecords(Doctor doctor);
	 
     public void EditRecordsforDoctor(Doctor doctor);


}
