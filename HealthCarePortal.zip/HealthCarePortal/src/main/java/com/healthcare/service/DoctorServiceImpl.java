package com.healthcare.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthcare.Entity.DoctorEntity;
import com.healthcare.dao.DoctorRepository;
import com.healthcare.exception.ResourceNotFoundException;
import com.healthcare.pojo.Doctor;

@Service
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	DoctorRepository doctorrepository;

	@Autowired
	ObjectMapper mapper;


	public void saveAllRecords(Doctor doctor) {
		DoctorEntity doctorentity = mapper.convertValue(doctor, DoctorEntity.class);
		doctorrepository.save(doctorentity);
		
	}

	public void EditRecordsforDoctor(Doctor doctor) {
		DoctorEntity doctorentity = mapper.convertValue(doctor, DoctorEntity.class);

		DoctorEntity doctorEntity = doctorrepository.findById((long) doctorentity.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + doctorentity.getId()));

		if (doctorEntity != null) {
			saveAllRecords(doctor);
		}

	}
}
