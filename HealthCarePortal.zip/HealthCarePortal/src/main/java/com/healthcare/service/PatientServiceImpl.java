package com.healthcare.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.healthcare.Entity.DoctorEntity;
import com.healthcare.Entity.PatientEntity;
import com.healthcare.dao.DoctorRepository;
import com.healthcare.dao.PatientRepository;
import com.healthcare.exception.ResourceNotFoundException;
import com.healthcare.pojo.Doctor;
import com.healthcare.pojo.Patient;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository patientrepository;

	@Autowired
	ObjectMapper mapper;


	@Override
	public void saveAllRecords(Patient patient) {
		PatientEntity patiententity = mapper.convertValue(patient, PatientEntity.class);
		patientrepository.save(patiententity);
	}

	@Override
	public void EditRecordsforPatient(Patient patient) {
         
		PatientEntity patiententity = mapper.convertValue(patient, PatientEntity.class);

		PatientEntity patiententity1 = patientrepository.findById((long) patiententity.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + patiententity.getId()));

		if (patiententity1 != null) {
			saveAllRecords(patient);
		}
	}

	@Override
	public void deleteRecordsforPatient(Long id) {
		// TODO Auto-generated method stub
		patientrepository.deleteById(id);
	}

	

}
