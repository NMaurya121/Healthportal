package com.healthcare.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.pojo.Doctor;
import com.healthcare.pojo.Patient;
import com.healthcare.service.DoctorServiceImpl;
import com.healthcare.service.PatientServiceImpl;

@RestController
@RequestMapping("/api/patient") 
public class PatientController {

	@Autowired
	PatientServiceImpl patientserviceimpl;
	private static final Logger logger = LoggerFactory.getLogger(HealthCareController.class);

	@PostMapping("/createDetailsforPatient")
	public ResponseEntity<String> SignupforDoctor(@RequestBody Patient patient) {
		logger.info("User Details enter here is  +:" + patient);
		patientserviceimpl.saveAllRecords(patient);
		return ResponseEntity.ok("The response Entity enter is :" + patient);
	}

	@PutMapping("/cditDetailsForPatient")
	public ResponseEntity<String> EditForDoctor(@RequestBody Patient patient) {
		logger.info("User Details for edit purpose+" + patient);
		patientserviceimpl.EditRecordsforPatient(patient);
		return ResponseEntity.ok("The response Entity enter is :" + patient);

	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> DeleteRecordsPatient(@PathVariable Long id)
	{
		
		logger.info("User Details for edit purpose+" + id);
		patientserviceimpl.deleteRecordsforPatient(id);

		return ResponseEntity.ok("The response Entity enter is :" + id);
		
	}
	

}
