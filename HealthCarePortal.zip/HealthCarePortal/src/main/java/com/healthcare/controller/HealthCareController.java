package com.healthcare.controller;

import org.apache.logging.log4j.spi.LoggerContextFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.healthcare.pojo.Doctor;
import com.healthcare.service.DoctorServiceImpl;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/doctors") 
public class HealthCareController {

	@Autowired
	DoctorServiceImpl doctorserviceimpl;
	private static final Logger logger = LoggerFactory.getLogger(HealthCareController.class);

	@PostMapping("/SignUpDoctor")
	public ResponseEntity<String> SignupforDoctor(@RequestBody Doctor doctor) {
		logger.info("User Details enter here is  +:" + doctor);
		doctorserviceimpl.saveAllRecords(doctor);
		return ResponseEntity.ok("The response Entity enter is :" + doctor);
	}
	
	@PutMapping("/EditDetailsForDoctor")
	public ResponseEntity<String> EditForDoctor(@RequestBody Doctor doctor)
	{
		logger.info("User Details for edit purpose+"+doctor);
		doctorserviceimpl.EditRecordsforDoctor(doctor);
		return ResponseEntity.ok("The response Entity enter is :" + doctor);
		
	}
    
	
}
