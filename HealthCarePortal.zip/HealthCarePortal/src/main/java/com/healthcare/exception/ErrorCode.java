package com.healthcare.exception;

public enum ErrorCode {
	
	 RESOURCE_NOT_FOUND(404);
	    // Add more enum constants here if needed

	    // Constructor to associate an integer value with each enum constant
	    private final int value;

	    private ErrorCode(int value) {
	        this.value = value;
	    }

	    // Getter method to retrieve the integer value associated with the enum constant
	    public int getValue() {
	        return value;
	    }

}
