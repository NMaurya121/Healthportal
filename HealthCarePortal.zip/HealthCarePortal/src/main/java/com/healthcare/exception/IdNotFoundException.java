package com.healthcare.exception;

public class IdNotFoundException extends RuntimeException{
	
	String message = "";
	public IdNotFoundException()
	{
		
	}
	public IdNotFoundException(String message)
	{
		super(message);
		this.message = message;
	}

}
