package com.healthcare.exception;

public class ResourceNotFoundException extends RuntimeException{

	String message;
	public ResourceNotFoundException()
	{
		
	}
	public ResourceNotFoundException(String message)
	{
		super(message);
		this.message = message;
	}
}
