package com.healthcare.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ErrorResponse {
	
	private ErrorCode statuscode;
	private String message;
	
	public ErrorResponse(String message)
	{
	   super();
	   this.message = message;
		
	}

	public ErrorResponse() {
		// TODO Auto-generated constructor stub
	}

	public void setErrorMessage(String message2) {
       this.message = message;
		
	}

	public void setErrorCode(ErrorCode resourceNotFound) {
		// TODO Auto-generated method stub
		this.statuscode = resourceNotFound;
	}

	@Override
	public String toString() {
		return "ErrorResponse [statuscode=" + statuscode + ", message=" + message + "]";
	}

}
