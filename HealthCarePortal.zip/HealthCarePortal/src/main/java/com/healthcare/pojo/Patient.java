package com.healthcare.pojo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Patient {

	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	private int Id;
	private String PatientName;
	private String Age;
	private String Patienthistroy;
	public String getPatientName() {
		return PatientName;
	}
	public void setPatientName(String patientName) {
		PatientName = patientName;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String age) {
		Age = age;
	}
	public String getPatienthistroy() {
		return Patienthistroy;
	}
	public void setPatienthistroy(String patienthistroy) {
		Patienthistroy = patienthistroy;
	}
	@Override
	public String toString() {
		return "Patient [PatientName=" + PatientName + ", Age=" + Age + ", Patienthistroy=" + Patienthistroy + "]";
	}
	public Patient(String patientName, String age, String patienthistroy) {
		super();
		PatientName = patientName;
		Age = age;
		Patienthistroy = patienthistroy;
	}
	public Patient() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
