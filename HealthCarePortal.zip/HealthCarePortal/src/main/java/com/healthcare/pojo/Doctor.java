package com.healthcare.pojo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Doctor  {
	
	private int Id;
	private String DoctorName;
	private String PhoneNo;
    private String Speciliest;
	public String getDoctorName() {
		return DoctorName;
	}
	public void setDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public void getDoctorName(String doctorName) {
		DoctorName = doctorName;
	}
	public String getPhoneNo() {
		return PhoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		PhoneNo = phoneNo;
	}
	public String getSpeciliest() {
		return Speciliest;
	}
	public void setSpeciliest(String speciliest) {
		Speciliest = speciliest;
	}
	@Override
	public String toString() {
		return "Doctor [DoctorName=" + DoctorName + ", PhoneNo=" + PhoneNo + ", Speciliest=" + Speciliest + "]";
	}
	public Doctor(String doctorName, String phoneNo, String speciliest) {
		super();
		DoctorName = doctorName;
		PhoneNo = phoneNo;
		Speciliest = speciliest;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	
	}
	

